## Sentetik deneyler (Anıl) — README'ye eklenecek bölüm

| Notebook | Ne yapar | Ürettiği dosyalar | Süre (CPU) |
|---|---|---|---|
| `notebooks/01_synthetic_online.ipynb` | E1: Şekil 1 online problemi (1010x / −10x). α ∈ {0.05, 0.1, 0.25, 0.5, 1} × {sabit, α/√t}, 1M adım grid → seçilenler 7M adım. Ablation: bias-correction + ε ve `torch.optim.Adam(amsgrad=True)` | `results/e1_stage1/`, `results/e1/`, `figures/e1.*`, `figures/e1_const.*`, `figures/e1_ablation.*` | ~10 dk |
| `notebooks/02_synthetic_stochastic.ipynb` | E2: stokastik sürüm (p = 0.01), 5 seed, 10M adım | `results/e2/`, `figures/e2.*` | ~11 dk |
| `notebooks/03_theorem1_heatmap.ipynb` | E3: Teorem 1'in birebir örneği (C ∈ {3,5,10}) + β₂ × C ısı haritası (β₁ = 0 ve 0.9) | `results/e3a/`, `results/e3b/heatmap.csv`, `figures/e3_theorem1.*`, `figures/e3_heatmap.*` | ~5 dk |

**Çalıştırma (Kaggle):** Accelerator = None (CPU yeterli) → Save Version → Save & Run All.
Hızlı test için ilk hücrelerdeki `QUICK` değişkenini `True` yap.

**Notlar:**
- Bütün konfigürasyonlar tek tensörde vektörize koşar (`simulate`).
- Notebook içindeki `paper_step`, `bias_correction=True, eps=1e-8` iken `torch.optim.Adam` ile birebir aynı sonucu verir (test hücresi, fark ~1e-16).
- `optim/optimizers.py` içindeki fonksiyonel `step()` için "Ortak optimizer" hücresinde `USE_COMMON = True` yapılır.
- CSV: ortak format + sentetiğe özel `x` ve `schedule` sütunları; `train_loss` = ortalama pişmanlık R_t/t.
